import React from 'react'

const Information = () => {
  return (
    <div>
      welcome to information page
    </div>
  )
}

export default Information
